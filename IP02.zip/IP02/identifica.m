x(:, 2) = output_real.signals.values;
x(:, 1) = output_real.time;

%Parametros pico e tp
[xm, im] = max(x(:, 2));
tp = x(im, 1);
xf = mean(x(end-100:end, 2));

%Parametros MP,ksi e wn
Mp = (xm - xf) / xf;
qsi = log(1 / Mp) / sqrt(pi^2 + (log(1 / Mp))^2);
wn = pi / (tp * sqrt(1 - qsi^2));

%Parametros a e b
a = 2 * qsi * wn;
b = wn^2;
k = (xf * wn^2);

%FT em MA
g = tf([k], [1 a 0]);
%FT em MF
gs = tf([k], [1 a b]);
%plot(x(:,1),x(:,2));
%step(gs)


%% Discretiza��o
ts = 0.01;
discretizado = c2d(gs, ts, 'zoh');
[num, den] = tfdata(discretizado, 'v');
polos = roots(den);
zeros = roots(num);

settling = 0.3;
qsi_projeto = 0.5;
omegan = 4 / (settling * qsi_projeto);
omegad = omegan * sqrt(1 - qsi_projeto^2);
omegas = 2 * pi / ts;
modulo_disc = exp(-((2 * pi * qsi_projeto * omegad)/(sqrt(1 - qsi_projeto^2) * omegas)));
fase_disc = 2 * pi * omegad / omegas;
p = modulo_disc*(cos(fase_disc)-1j*sin(fase_disc));

%% Calculo da defici�ncia angular
close all;
rlocus (discretizado); hold on;
scatter (real(p),imag(p), 'filled');

contrib_ang_zero = atan(imag(p)/(real(p)-zeros(1))); %radianos
contrib_ang_polo1 = atan(imag(p)/(real(p)-polos(1))); %radianos
contrib_ang_polo2 = atan(imag(p)/(real(p)-polos(2))); %radianos

soma_das_contrib_ang_em_p = contrib_ang_zero - contrib_ang_polo1 - contrib_ang_polo2; %radianos
deficiencia_angular = soma_das_contrib_ang_em_p - pi; %radianos

%% controlador
k_gd = 1;
beta = tan(deficiencia_angular - contrib_ang_polo2)*imag(p)*4;
g_d = k_gd * tf([1 -polos(2)], [1 -beta], ts);
ggd = g_d * discretizado;
rlocus (ggd)




