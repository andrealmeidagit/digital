/*
 * identifica_ip02_types.h
 *
 * Real-Time Workshop code generation for Simulink model "identifica_ip02.mdl".
 *
 * Model Version              : 1.506
 * Real-Time Workshop version : 7.2  (R2008b)  04-Aug-2008
 * C source code generated on : Thu Oct 31 09:47:59 2019
 */
#ifndef RTW_HEADER_identifica_ip02_types_h_
#define RTW_HEADER_identifica_ip02_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_identifica_ip02_ Parameters_identifica_ip02;

/* Forward declaration for rtModel */
typedef struct RT_MODEL_identifica_ip02 RT_MODEL_identifica_ip02;

#endif                                 /* RTW_HEADER_identifica_ip02_types_h_ */
